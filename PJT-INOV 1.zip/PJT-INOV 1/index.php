<form method="post">
    Nome: <input type="text" name="nome"><br><br>
    Idade: <input type="number" name="idade"><br><br>
    Cidade: <input type="text" name="cidade"><br><br>
    Curso: <input type="text" name="curso"><br><br>
    <input type="submit" value="Enviar">
</form>

<?php
if ($_POST) {
    $nome = $_POST['nome'];
    $idade = $_POST['idade'];
    $cidade = $_POST['cidade'];
    $curso = $_POST['curso'];

    echo "<br>A aluna $nome, de $idade anos, mora em $cidade e está matriculada no curso $curso.";
}
?>