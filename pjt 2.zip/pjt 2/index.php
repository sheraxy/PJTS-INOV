<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <title>PagFacil</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <h1>PagFacil</h1>
    <p>Gerencie seus boletos de forma prática e rápida.</p>

    <form  method="post" action="">

        <label> Nome do Boleto:</label>
        <input type="text" name="nome" required><br><br>

        <label> Valor (R$):</label>
        <input type="number" step="0.01" name="valor" required><br><br>

        <label> Data de Vencimento:</label>
        <input type="date" name="vencimento" required><br><br>

        <button type="submit">Cadastrar</button>
    </form>

    <?php
    if ($_SERVER["REQUEST_METHOD"] == "POST") {
        $nome = $_POST['nome'];
        $valor = $_POST['valor'];
        $vencimento = $_POST['vencimento'];

        echo "<div class='resultado'>";

        echo "<h2>Dados do boleto</h2>";
        echo "<p><strong>Nome do Boleto:</strong> $nome</p>";
        echo "<p><strong>Valor:</strong> R$ $valor</p>";
        echo "<p><strong>Data de Vencimento:</strong> $vencimento</p>";
        
        echo "</div>";
    }
    ?>

<h1>Dados do Boleto</h1>

</body>
</html>

