<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <title>Verificação de Salário e Bônus</title>
</head>
<body>

    <form method="POST" action="">
        <label>Nome do Funcionário:</label><br>
        <input type="text" name="nome" required><br><br>

        <label>Salário (R$):</label><br>
        <input type="number" step="0.01" name="salario" required><br><br>

        <label>Bônus (R$):</label><br>
        <input type="number" step="0.01" name="bonus" required><br><br>

        <button type="submit" name="verificar">Verificar</button>
    </form>

    <br><hr><br>

    <?php
    if (isset($_POST['verificar'])) {
        $nome = $_POST['nome'];
        $salario = (float)$_POST['salario'];
        $bonus = (float)$_POST['bonus'];

        // Meta de bônus
        $meta = 700;

        echo "<h3>Resultado da Verificação:</h3>";
        echo "Funcionário: " . htmlspecialchars($nome, ENT_QUOTES) . "<br>";
        echo "Salário: R$ " . number_format($salario, 2, ',', '.') . "<br>";
        echo "Bônus: R$ " . number_format($bonus, 2, ',', '.') . "<br>";

        // Verificação do salário
        if ($salario >= 5000) {
            echo "Classificação: Funcionário Premium<br>";
        } else {
            echo "Classificação: Funcionário Padrão<br>";
        }

        // Verificação da meta de bônus
        if ($bonus >= $meta) {
            echo "Meta de bônus atingida!";
        } else {
            echo "Meta de bônus não atingida!";
        }
    }
    ?>

</body>
</html>
