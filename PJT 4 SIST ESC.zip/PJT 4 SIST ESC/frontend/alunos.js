// Função para carregar alunos da memória local
function carregarAlunos() {
    const alunos = JSON.parse(localStorage.getItem("alunos")) || [];
    const tabela = document.querySelector("#tabela-alunos tbody");
    if (tabela) {
      tabela.innerHTML = "";
      alunos.forEach(aluno => {
        const tr = document.createElement("tr");
        tr.innerHTML = `
          <td>${aluno.nome}</td>
          <td>${aluno.idade}</td>
          <td>${aluno.email}</td>
          <td>${aluno.CGM}</td>
        `;
        tabela.appendChild(tr);
      });
    }
  }
  
  // Função para cadastrar aluno
  function cadastrarAluno(event) {
    event.preventDefault();
    const nome = document.getElementById("nome").value;
    const idade = document.getElementById("idade").value;
    const email = document.getElementById("email").value;
    const CGM = document.getElementById("CGM").value;
  
    const novoAluno = { nome, idade, email, CGM };
    const alunos = JSON.parse(localStorage.getItem("alunos")) || [];
    alunos.push(novoAluno);
    localStorage.setItem("alunos", JSON.stringify(alunos));
  
    alert("Aluno cadastrado com sucesso!");
    document.getElementById("form-aluno").reset();
  }
  
  // Inicialização
  document.addEventListener("DOMContentLoaded", () => {
    if (document.getElementById("form-aluno")) {
      document.getElementById("form-aluno").addEventListener("submit", cadastrarAluno);
    }
    carregarAlunos();
  });
  